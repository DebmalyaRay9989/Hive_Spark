import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
public class HiveThrift
{
private static String driverName = "org.apache.hive.jdbc.HiveDriver";
public static void main(String args[]) throws SQLException{
try{
	Class.forName(driverName);
}
catch(ClassNotFoundException e){
//TODO Auto-generated catch block
e.printStackTrace();
System.exit(1);
}
Connection con =  DriverManager.getConnection("jdbc:hive2://ip-20-0-21-85.ec2.internal:10000/default");
Statement stmt = con.createStatement();
String databaseName="hivejdbc_db";
String tableName = "products";
//String fileName="/mnt/bigdatapgp/edureka_396201/products1.csv";
String fileName="hdfs://ip-20-0-21-161.ec2.internal/user/edureka_396201/products1.csv";
stmt.execute("drop database if exists " +databaseName +" cascade");
stmt.execute("create database " +databaseName);
stmt.execute("use " +databaseName);
stmt.execute("drop table if exists " +tableName);
stmt.execute("create table " +tableName+ "(productid int, productname string,price int) row format delimited fields terminated by ',' ");
//show tables
System.out.println("Show table in the database: " +databaseName);
ResultSet res = stmt.executeQuery("show tables");
while(res.next()){
System.out.println(res.getString(1));    
}
//describe table
System.out.println("describe table " +tableName);
res = stmt.executeQuery("describe " +tableName );
while(res.next()){
System.out.println(res.getString(1) + "\t" +res.getString(2));
}
//System.out.println("insert into  "+tableName +"(productid, productname, price)  values(1,'phone',20000)");
stmt.executeQuery("insert into  "+tableName +"(productid, productname, price)  values(1,'phone',20000)");
//res = stmt.executeQuery("load data inpath '" + fileName + "' into table " + tableName);

System.out.println("Read table " +tableName);
res = stmt.executeQuery("select * from " +tableName );
while(res.next()){
System.out.println(res.getInt(1) + "\t" +res.getString(2)+"\t" +res.getInt(3));
}
}
}

